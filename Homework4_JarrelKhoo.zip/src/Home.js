import React from "react";

export default class Home extends React.Component {

    render() {
        return (
            <div>
                <h2> Kitchen Inventory Manager 1.0 </h2>
                <h3> </h3>
            </div>
        )
    }
}